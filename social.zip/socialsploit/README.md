# SocialSploit 
     Installation
     pkg install -y git
     git clone https://github.com/Cesar-Hack-Gray/SocialSploit
     cd SocialSploit
     ls
     bash install.sh
     ./Sploit
# Installation 
##### https://youtu.be/z9FmwGOo3A8
# Example
![CollageMaker_20191115_193409432](https://user-images.githubusercontent.com/46208706/68985841-31a1a500-07df-11ea-9d0c-abff6a2f8c49.jpg)

#### ● SocialSploit es un framework de phishing que nos ayuda a hackear con ngrok y serveo :3 
#### ● se trata de ingeniería social recuerda esto no me hago responsable del mal uso
       
       requisitos ->  curl, php, ssh, python2 y wget
       
  
# SocialSploit 
![Screenshot_20191114-181630_Termux~01](https://user-images.githubusercontent.com/46208706/68985817-f8693500-07de-11ea-8a64-592468ed1440.jpg)
# Mi redes sociales
    YouTube  : http://youtube.com/c/CésarHackGray_Y_Miickeyy
    Telegram : https://t.me/CesarGray
    Facebook : Cesar Hack Gray
    Mi web   : https://www.CesarHackGray.com 
# Disfruta -> SocialSploit by @CesarHackGray
